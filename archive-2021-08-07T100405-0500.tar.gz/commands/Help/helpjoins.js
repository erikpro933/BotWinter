module.exports = {
    name: 'joins-help',
    code: `$title[Help joins]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setwchannel\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setwmessage\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setlchannel\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setlmessage\`\`\`]
$addField[Variales; You can use all guild and member based functions like $ serverName or $ guildID or $ username or $ authorID in these commands.]
$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]
`
}
