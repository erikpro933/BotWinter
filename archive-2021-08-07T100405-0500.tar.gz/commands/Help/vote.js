module.exports = {
name: "vote",
code: `$title[MI LINK PARA VOTAR!]
$description[https://top.gg/bot/856597592008163379]
$color[#00e1fc]
$footer[Dadle las gracias a mi creador Heiron]
$addReactions[😎;🏆;📨;👩‍💻]
`
}