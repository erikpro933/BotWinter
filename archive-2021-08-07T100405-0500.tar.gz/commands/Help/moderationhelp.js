module.exports = {
    name: 'moderation-help',
    code: `$title[Help Moderation]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]announce\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]ban\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]invite\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]kick\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]purge\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]serverinfo\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]slowmode\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]userinfo\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]audit-logs\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setprefix\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]checkwarnings\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]clearwarnings\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]lock\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]unlock\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]unwarn\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]warn\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]snipe\`\`\`

¡Disfruta del bot!]
$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]
`
}
