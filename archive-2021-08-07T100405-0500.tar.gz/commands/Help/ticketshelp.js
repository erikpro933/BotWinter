module.exports = {
    name: 'tickets-help',
    code: `$title[Help tickets]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]new\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]close\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]settmessage\`\`\`
`
}