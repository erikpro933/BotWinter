module.exports = {
    name: 'roles-help',
    code: `$title[Help roles]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]add-role\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]remove-role\`\`\`
¡Disfruta del bot!]
$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]
`
}