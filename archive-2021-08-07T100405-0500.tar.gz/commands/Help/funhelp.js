module.exports = ({

  name: "fun-help",

  code: `



$title[Help fun]

$color[#ffaaaa]

$description[<a:flechablanca:822145593056952370>\`\`\`
$getServerVar[Prefix]8ball\`\`\` (type a question) 

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]howgay\`\`\` (mention user)

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]batalla\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]tell\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]search\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]meme\`\`\` (no es como todos porque es mas facil de escribir)

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]love\`\`\` (mention user)

Si te gusta el bot vota [aquí](https://top.gg/bot/856597592008163379)]
`
})
