module.exports = ({

  name: "economy-help" ,

  code: `$title[Help economy]

$color[#ffaaaa]

$description[<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]weekly (paga semanal)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]work (para trabajar)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]add-money (sumar dinero a la cuenta de alguien)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]pay (para pagar a alguien)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]top (para ver el top de quien tiene más dinero en el servidor)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]bal (para ver tu dinero en el banco)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]resetbalance (para resetear la economía entera)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]resetmoney (para resetear la economía de un usuario entero)\`\`\`

<a:flechablanca:822145593056952370>\`\`\`$getServerVar[Prefix]removemoney (para quitarle el dinero a un usuario)\`\`\`]

$addField[Vote Us!;Si te gusta el bot vota [aquí](https://top.gg/bot/856597592008163379)]`

})

