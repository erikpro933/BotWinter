module.exports = {
    name: "words-help",
    code: `
$title[Help Messages]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]mtop\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]message\`\`\`]
`
}