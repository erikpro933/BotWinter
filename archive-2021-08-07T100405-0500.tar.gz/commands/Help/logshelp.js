module.exports = ({
name: "logs-help",
code:` $title[Logs help] 
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setcchannel (create channel)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setdchannel (delete channel)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setdrchannel (delete role)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setmdchannel (message delete)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setucchannel (update channel)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]setumchannel (update message)\`\`\`] 
$color[RANDOM]
`
})