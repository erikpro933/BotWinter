module.exports = {
    name: 'music-help',
    code: `$title[Help Music]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]play\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]skip\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]stop\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]clear-queue\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]loop-song\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]loop-queue\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]pause\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]queue\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]resume\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]seek\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]skipTo\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]volume\`\`\`

¡Disfruta del bot!]
$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]
`
}