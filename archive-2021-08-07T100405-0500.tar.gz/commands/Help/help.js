module.exports = {
    name: 'help',
    code: `$title[Help]
$color[#ffaaaa]
$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]economy-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]fun-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]moderation-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]roles-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]lvl-help\`\`\`

<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]vote (si votas te lo agradecería mucho)\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]tickets-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]joins-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]music-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]words-help\`\`\`
<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]logs-help\`\`\`


¡Disfruta del bot!]
$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]
`
}
