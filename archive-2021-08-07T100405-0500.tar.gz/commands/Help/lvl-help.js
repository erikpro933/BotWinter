module.exports = {

    name: 'lvl-help',

    code: `$title[Help]

$color[#ffaaaa]

$description[<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]level\`\`\`

<a:flecharosa:822145744639229962>\`\`\`$getServerVar[Prefix]ltop\`\`\`

¡Disfruta del bot!]

$addField[Vote Us!;Si te gusta el bot vota [aquí\](https://top.gg/bot/856597592008163379)]

`

}

