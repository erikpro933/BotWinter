module.exports = {
name: "ltop",
code: `$title[__Level top__] $description[$userLeaderboard[level;asc]] 

$color[$random[0;9999]]

$footer[Command Executed by $username]
`
}