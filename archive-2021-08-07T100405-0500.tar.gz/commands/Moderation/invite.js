module.exports = {
name: "invite",
code: `Invite:  https://discord.com/oauth2/authorize?client_id=856597592008163379&scope=bot+applications.commands&permissions=8`
} 