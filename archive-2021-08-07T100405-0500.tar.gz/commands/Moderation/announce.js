module.exports = {
    name: 'embed',
    code: `$title[$message[2]]
$footer[embed by: $username]
$description[$message[3] $message[4] $message[5] $message[6] $message[7] $message[8] $message[9] $message[10] $message[11] $message[12] $message[13] $message[14] $message[15] $message[16] $message[17] $message[18] $message[19] $message[20] $message[21] $message[22] $message[23] $message[24] $message[25] $message[26] $message[27] $message[28] $message[29] $message[30] $message[31] $message[32] $message[33] $message[34] $message[35] $message[36] $message[37] $message[38] $message[39] $message[40] $message[41] $message[42] $message[43] $message[44] $message[45] $message[46] $message[47] $message[48] $message[49] $message[50] $message[51] $message[52] $message[53] $message[54] $message[55] $message[56] $message[57] $message[58] $message[59] $message[60] $message[61]]
$color[$message[1]]`
} 
