module.exports = {
name: "setprefix",
code: `$setServerVar[Prefix;$message]
Mi prefijo en este servidor es ahora $message
`}