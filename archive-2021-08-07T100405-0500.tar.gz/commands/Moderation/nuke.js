module.exports = ({
 name:"nuke",
 code:` $deleteChannels[$channelID]
$dm
$cloneChannel
$description[**Canal Nukeado Correctamente ✅**]
$onlyPerms[managechannels;managemessages;**Usted no puede usar este comando!**]
$color[FDFEFE]`
}) 