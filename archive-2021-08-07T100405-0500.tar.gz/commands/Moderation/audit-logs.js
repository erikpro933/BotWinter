module.exports = {
name: "audit-logs",
code: `
Last audit log entries:
$getAuditLogs
`
}