module.exports = {

name: "resetInvites",

code: `

Successfully reset invites for $username[$mentioned[1]]

$resetInvites[$guildID;$mentioned[1]]

`

}