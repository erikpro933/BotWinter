module.exports = ({
name: "isLink", 
code: `Is Link: $isValidLink[$message]` 
})