module.exports = ({
    name: "servers",
    code: `Server names: $serverNames`
    //will return: serverName,serverName,serveName,etc
})