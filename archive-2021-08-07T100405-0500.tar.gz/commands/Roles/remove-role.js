module.exports = {
name: "remove-role",
code: `$onlyPerms[manageroles;No tienes permisos]
$takeRole[$mentioned[1];$mentionedRoles[1]]
<a:flecharosa:822145744639229962> **se a removido el rol correctamente** .
`
}