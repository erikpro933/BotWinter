module.exports = {
name: "add-role",
code: `$onlyPerms[manageroles;<a:nops:770033114277609504> No tienes los permisos necesarios para ejecutar este comando.]

$giveRole[$mentioned[1];$mentionedRoles[1]]

<a:flecharosa:822145744639229962> **se a agregado el rol correctamente**
`
}