module.exports = ({
name: "antilink",
code: `
$if[$toLowerCase[$message]==enable]
$setServerVar[antilink;true]
Antilink successfully enabled!
$onlyBotPerms[managemessages;I don't have enough permissions!]
$onlyIf[$getServerVar[antilink]==false;Antilink already enabled!]
$elseIf[$toLowerCase[$message]==disable]
$setServerVar[antilink;false]
Antilink successfully disabled!
$onlyIf[$getServerVar[antilink]==true;Antilink already disabled!]
$endelseIf
$else
Antilink status: $replaceText[$replaceText[$getServerVar[antilink];true;Enabled];false;Disabled]
$endif
$onlyPerms[managemessages;You don't have enough permissions!]
`})