module.exports = ({
    name: "$alwaysExecute",
    code: `$setUserVar(spam;0)
$wait(5s)
$setUserVar(spam;$sum($getUserVar(spam);1))
$onlyIf($getUserVar(spam)<=3;{execute:spam})`
}, {
    type: 'awaitedCommand',
    name: "spam",
    code: `$deleteIn(3s)
**Please Avoid Spamming!**
$deletecommand`
}, {
    name: "spamlist",
    code: `$getUserVar(spam)`
})