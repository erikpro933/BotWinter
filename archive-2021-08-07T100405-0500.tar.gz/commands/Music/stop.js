module.exports = ({
name:"stop",
code:`$stopSong song stoped`
})