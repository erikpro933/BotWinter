module.exports = ({
name:"resume",
code: `$resumeSong`
})