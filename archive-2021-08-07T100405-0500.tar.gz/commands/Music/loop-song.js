module.exports = ({
    name: "loop-song",
    code: `
    Looping current song.
    $loopSong
    `
})