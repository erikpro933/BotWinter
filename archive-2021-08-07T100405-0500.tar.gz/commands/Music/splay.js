module.exports = ({
name: "splay",
code: `$playSpotify[$message;number;yes;:x: An error has occured]
`
})