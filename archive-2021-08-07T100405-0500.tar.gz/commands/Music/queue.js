module.exports = ({
name: "queue",
code: `$queue[1;10;{number} - {title} by <@{userID}>]`
})