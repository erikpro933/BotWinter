module.exports = ({
name: "volume",
code: `
$volume[$message]
`
})