module.exports = ({
name: "seek",
code: `
$seekTo[$message]
`})