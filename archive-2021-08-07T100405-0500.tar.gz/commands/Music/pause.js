module.exports = ({
name:"pause",
code:`$pauseSong`
})