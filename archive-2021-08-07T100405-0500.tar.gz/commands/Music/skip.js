module.exports = ({
name:"skip",
code:`$skipSong`
})