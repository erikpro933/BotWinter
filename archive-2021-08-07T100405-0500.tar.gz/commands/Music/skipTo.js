module.exports = ({
name: "skipTo",
code: `$skipTo[3]` //Skips to the 3rd song
})