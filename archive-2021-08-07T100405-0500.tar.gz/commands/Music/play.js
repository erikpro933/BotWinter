module.exports = ({

name: "play",

code: `$playSong[$message;1m;yes;yes;:x: Could not play song!]`

})
