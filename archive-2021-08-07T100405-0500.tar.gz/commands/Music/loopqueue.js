module.exports = ({
name: "loop-queue",
code: `Looped the queue! $loopQueue`
})