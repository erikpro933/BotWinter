module.exports = {

name: "setucchannel",

code: `$setServerVar[uchannel;$mentionedChannels[1]]

$title[Channel update channel log set!]

$footer[]

$color[7eff00]

$onlyPerms[admin;You need \`Administrator\` perm to set a channel !]

$addReactions[👍]

`
}