module.exports = {

name: "setcrchannel",

code: `$setServerVar[crole;$mentionedChannels[1]]

$title[Channel create rol log set!]

$footer[]

$color[7eff00]

$onlyPerms[admin;You need \`Administrator\` perm to set a channel !]

$addReactions[👍]

`
}