module.exports = {

name: "setdrchannel",

code: `$setServerVar[drole;$mentionedChannels[1]]

$title[Channel delete rol log set!]

$footer[]

$color[7eff00]

$onlyPerms[admin;You need \`Administrator\` perm to set a channel !]

$addReactions[👍]

`
}