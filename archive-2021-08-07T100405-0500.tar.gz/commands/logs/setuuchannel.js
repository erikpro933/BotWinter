module.exports = {

name: "setuuchannel",

code: `$setServerVar[uuser;$mentionedChannels[1]]

$title[Channel update user log set!]

$footer[]

$color[7eff00]

$onlyPerms[admin;You need \`Administrator\` perm to set a channel !]

$addReactions[👍]

`
}