module.exports = {

name: "setwmessage",

code: `$setServerVar[wmessage;$message]

$title[Welcome message set!]

$footer[]

$color[7eff00]

$onlyPerms[admin;You need \`Administrator\` perm to set a welcome message!]

$addReactions[👍]

`

}