module.exports = ({

  name: "serverinvite",

  code: `$argsCheck[0; ]

$color[dcaeee]

$onlyPerms[createinstantinvite;You dont have permission "Create Instant Invite"]$description[

Invite to this server

$getServerInvite]`

})

