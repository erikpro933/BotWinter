module.exports = ({

  name: "tell",

  code: `$deletecommand

$author[$username] $authorIcon[image;username]

$description[$message]`

})

