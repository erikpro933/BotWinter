module.exports = ({

  name: "ping",

  code: `$title[MY PING …]

$color[61790]

$description[$ping MS]

$image[https://cdn.discordapp.com/attachments/581578990020460575 582164322474524691/62095a07383bb4a02343c9660644c8tenor.gif]`

})

