module.exports = ({

  name: "meme",

  code: `$color[#ff2050]

$title[MEME]

$image[https://ctk-api.herokuapp.com/meme/$random[1;500]]`

})

