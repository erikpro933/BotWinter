module.exports = ({

  name: "love",

  code: `$color[ff64c2]

$title[❤️ PORCENTAJE DE AMOR ❤️]

$image[https://i.imgur.com/OuSxRg5.gif]

$thumbnail[https://i.imgur.com/OuSxRg5.gif]

$description[**<@$mentioned[1]>** Y **<@$mentioned[2]>** Se Aman Un **$random[0;100]%**]

$argsCheck[2;Menciona a dos usuarios.]`

})

