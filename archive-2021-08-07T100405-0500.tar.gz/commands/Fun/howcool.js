module.exports = ({

  name: "howcool",

  code: `$title[Cool Machine]

$color[$random[0000;9999]]

$description[You Are $random[0;100]% cool 😎]`

})

