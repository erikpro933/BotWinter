module.exports = {
    name: 'batalla',
    code: `$color[$randomText[65280;16711680;C8C864;47eabc;df2e90;543683;264bec;d20057;515e63;497147;376034;087264;4ca6ff;460a18;faebd7;eed330;cb4bca;fffff2;fffc3c;b507db;ff8d00;00ff38;ff00e7;98bdf0;daf7f8;b9e0d9;debcb0;ffb3b3;b8d9d0;83d0f2;552f2e;fff380;0000ff;ff4d00;afb169;afaf0a;ffffff;c7ae71;a77c86;17264f;cbffe8;c7bbc9;debcb0;010649;feebe6]]
$title[$username]
$description[a lanzado $random[1;100] barcos, $random[1;100] cohetes, $random[1;100] nukes, and $random[1;100] tropas. El enemigo a lanzado $random[1;100] cohetes, $random[1;100] nukes, $random[1;100] tropas, i $random[1;100] barcos.


Can you get more next round and defeat the enemy team?
$randomText[✅ has ganado está ronda.;❌ has perdido esta ronda.]]
$addReactions[⚔️;🗡️;🛡️]`
}
