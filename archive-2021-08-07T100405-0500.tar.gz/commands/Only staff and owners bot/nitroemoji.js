module.exports = {
    name: 'nitroemoji',
    code: `
\`\`\`$customEmoji[$message[>1]]\`\`\`
$argsCheck[>1; Pon el nombre de un emoji]
`
}
