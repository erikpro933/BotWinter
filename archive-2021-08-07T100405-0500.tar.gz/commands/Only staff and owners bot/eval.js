module.exports = {
    name: 'eval',
    code: `$eval[$message]
$onlyForIDs[773750233762103296;605069039068250132;no]`
}