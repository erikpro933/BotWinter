module.exports = {
    name: 'bal',
    code: `$title[Dinero]
$color[2737]
$description[$username Tienes  $getGlobalUserVar[money] €
]`
}
