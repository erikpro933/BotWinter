module.exports = {
    name: 'work',
    code: `$setGlobalUserVar[money;$sum[$getGlobalUserVar[money];$random[0;200]]]
Has trabajado de $randomText[Camarero;Profesor;Doctor;Turista;Comisario;Repartidor;Cajero;Cocinero] y has ganado $random[0;200]€
vota en https://top.gg/bot/821496737155776544 para ganar más dinero la próxima vez
`
}
