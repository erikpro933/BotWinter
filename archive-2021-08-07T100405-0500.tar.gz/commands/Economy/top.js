module.exports = {
    name: 'top',
    code: `
$title[**Leaderboard**]
$userLeaderboard[money;asc;{top} - {username} - {value}]
$color[RANDOM]
$footer[Command Executed by $username]`
}
