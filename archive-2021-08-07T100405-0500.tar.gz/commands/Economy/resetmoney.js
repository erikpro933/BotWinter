module.exports = ({

  name: "resetmoney",

  code: `

$resetUserVar[money]

$title[**>> User money has been reset <<**]

$argsCheck[>1;\`\`\`Do w!resetmoney <user>\`\`\`]

$onlyAdmin[**You do not have permission to use this command !**]`

})

