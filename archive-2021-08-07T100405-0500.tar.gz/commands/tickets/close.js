module.exports = {

name: "close",
code: `$closeTicket[This is not a ticket!]
`

}